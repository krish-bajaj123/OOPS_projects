 #include "textprocess.h"

TextProcessor::~TextProcessor() {}

