#include "canvas.h"

Canvas::Canvas() : capacity_(5), numRectangles_(0), rectangles_(new Rectangle[capacity_]) {}

Canvas::Canvas(const Canvas& other) : capacity_(other.capacity_), numRectangles_(other.numRectangles_), rectangles_(new Rectangle[capacity_]) {
    for (int i = 0; i < numRectangles_; ++i) {
        rectangles_[i] = other.rectangles_[i];
    }
}

Canvas::~Canvas() {
    delete[] rectangles_;
}

Canvas& Canvas::operator=(const Canvas& other) {
    if (this != &other) {
        delete[] rectangles_;
        capacity_ = other.capacity_;
        numRectangles_ = other.numRectangles_;
        rectangles_ = new Rectangle[capacity_];
        for (int i = 0; i < numRectangles_; ++i) {
            rectangles_[i] = other.rectangles_[i];
        }
    }
    return *this;
}

void Canvas::empty() {
    numRectangles_ = 0;
}

void Canvas::add(const Rectangle& rectangle) {
    if (numRectangles_ == capacity_) {
        resize();
    }
    rectangles_[numRectangles_++] = rectangle;
}

int Canvas::numRectangles() const {
    return numRectangles_;
}

int Canvas::getWidth() const {
    int width = 0;
    for (int i = 0; i < numRectangles_; ++i) {
        int x = rectangles_[i].getPoint().getX() + rectangles_[i].getWidth();
        if (x > width) {
            width = x;
        }
    }
    return width;
}

int Canvas::getHeight() const {
    int height = 0;
    for (int i = 0; i < numRectangles_; ++i) {
        int y = rectangles_[i].getPoint().getY() + rectangles_[i].getHeight();
        if (y > height) {
            height = y;
        }
    }
    return height;
}

Rectangle Canvas::get(int rectangleId) const {
    return rectangles_[rectangleId];
}

void Canvas::translate(int rectangleId, int x, int y) {
    rectangles_[rectangleId].translate(x, y);
}

void Canvas::scale(int rectangleId, float heightFactor, float widthFactor) {
    rectangles_[rectangleId].scale(heightFactor, widthFactor);
}

void Canvas::change(int rectangleId, Colour newColour) {
    rectangles_[rectangleId].change(newColour);
}

void Canvas::remove(int rectangleId) {
    for (int i = rectangleId; i < numRectangles_ - 1; ++i) {
        rectangles_[i] = rectangles_[i + 1];
    }
    --numRectangles_;
}

void Canvas::resize() {
    capacity_ *= 2;
    Rectangle *temp = new Rectangle[capacity_];
    for (int i = 0; i < numRectangles_; ++i) {
        temp[i] = rectangles_[i];
    }
    delete[] rectangles_;
    rectangles_ = temp;
}
